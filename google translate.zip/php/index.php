<?php


require 'vendor/autoload.php';

$inputFile = './2.json';
$outFile = 'thai2.json';


use Stichoza\GoogleTranslate\GoogleTranslate;

$tr = new GoogleTranslate(); // Translates to 'en' from auto-detected language by default
$tr->setSource('zh'); // Translate from English
$tr->setSource(); // Detect language automatically
$tr->setTarget('th'); // Translate to Georgian


$json_str = file_get_contents($inputFile);
$json_arr = json_decode($json_str,True);


echo 'total:' . count($json_arr). "\n";
file_put_contents($outFile,'['. "\n");
$arr = [];
foreach ($json_arr as $key => $val ){
    $str="    {" . "\n";

    foreach ($val as $k => $v){
        $str.='        "'.$k.'":';
        if (in_array($k, ['id','url','answer']) || $v == '') {
            $en = $v;
        }else{
            if (array_key_exists('m'.md5($v),$arr)) {
                $en = $arr['m'.md5($v)];
            }else{
                $en = $tr->translate($v);
                $en = str_replace('"', ' ', $en);
                $arr['m'.md5($v)] = $en;
                sleep(3);
           }
       }
       $str.=' "' . $en . '",' . "\n";
   }

   $str = trim($str,"\n");
   $str = trim($str,',');
   $str.="\n";
   $str.="    },". "\n";

   file_put_contents($outFile,$str,FILE_APPEND);

   echo $key ."\n";
}


file_put_contents($outFile,']',FILE_APPEND);
echo 'done';
