<?php

namespace App\Http\Controllers\Web;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Stichoza\GoogleTranslate\GoogleTranslate;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use App\driving_questions;


class IndexController extends Controller
{
    //

    public function  test(){

        //$tr = new GoogleTranslate('en'); // Translates into Engl
        $tr = new GoogleTranslate(); // Translates to 'en' from auto-detected language by default
        $tr->setSource('cn'); // Translate from English
        $tr->setSource(); // Detect language automatically
        $tr->setTarget('en'); // Translate to Georgian


        $json_str = Storage::get('json1.json');
        $json_arr = json_decode($json_str,True);
        $file_name='1.txt';
        echo "<pre>";echo '111';die();
        echo $tr->translate("啊啊所多啊啊所多发的");die();
        //print_r($json_arr);
        Storage::append($file_name,'[');
        foreach ($json_arr as $key => $val ){
            $str="{";

            foreach ($val as $k => $v){
                $str.="'$k':";
                $en = $tr->translate($v);
                $str.="'$en',\r\n";
            }

            $str.="}";
            echo $str . '---------'.$key;
            die();
            Storage::append($file_name,$str);
        }
        Storage::append($file_name,']');
        echo "inside here!!". $aa;
        exit();

    }


    public function dataInsert(){

        $fileName= 'json40.json';
        $json_str = Storage::get($fileName);
        $json_arr = json_decode($json_str,True);

        echo "<pre>";


        foreach ($json_arr as $key => $val ){
            $val['qid'] = $val['id'] ?? random_int(1000,999999);
            unset($val['id']);
            $val['type'] = 4;
            print_r($key);
            print_r($val);
            echo "<br />";//exit();



            driving_questions::create($val);


        }

        echo "finish------";
//        User::create([
//            'name' => $data['name'],
//            'email' => $data['email'],
//            'password' => Hash::make($data['password']),
//        ]);
    }

    public function drivingQuestion(){

        $type = request("type",1);
        $num = request("num",100);
        $page = request("page",1);

        $data = driving_questions::where('type',$type)->paginate($num);
        $data = $data->toArray();
        echo "<pre>";print_r($data);
    }
}
