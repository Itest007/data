<?php

require 'vendor/autoload.php';

$inputFile = './Item1.json';
$outFile = 'out1.json';

use Stichoza\GoogleTranslate\GoogleTranslate;

$tr = new GoogleTranslate(); // Translates to 'en' from auto-detected language by default
$tr->setSource('cn'); // Translate from English
$tr->setSource(); // Detect language automatically
$tr->setTarget('ko'); // Translate to Georgian



$json_str = file_get_contents($inputFile);
$json_arr = json_decode($json_str,True);


echo 'total:' . count($json_arr);
file_put_contents($outFile,'['. "\n");

foreach ($json_arr as $key => $val ){
    $str="    {" . "\n";

    var i = 0;

    foreach ($val as $k => $v){
        $str.='        "'.$k.':';
        $timeB = microtime(true);
        $en = $tr->translate($v);
        $timeE = microtime(true);
        echo 'runtime:' . $timeB - $timeE;
        $str.=' "' . $en . '",' . "\n";
        sleep(3);
    }

    $str = trim($str,"\n");
    $str = trim($str,',');
    $str.="\n";
    $str.="    },". "\n";

    file_put_contents($outFile,$str,FILE_APPEND);

    echo $key ."\n";
}


file_put_contents($outFile,']',FILE_APPEND);
echo 'done';
