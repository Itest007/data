<?php


$timeB = microtime(true);
sleep(3);
$timeE = microtime(true);